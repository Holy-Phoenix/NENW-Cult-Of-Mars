name="New Era New World - Cult of Mars"
archive="mod/NENWCultOfMars"
dependencies=
picture="cult_of_mars.png"

replace_path = "common/governments"